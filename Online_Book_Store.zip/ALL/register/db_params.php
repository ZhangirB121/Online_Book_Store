<?php

// Массив с параметрами подключения к базе данных
return array(
    'host' => 'localhost',
    'dbname' => 'online_book_store',
    'user' => 'root',
    'password' => '',
);
